# AltStore [(ALPHA)Jailbroken]

AltStore with on device signing and sideloading for Jailbroken iDevices.

## Getting Started

- A Jailrboken device with iOS 12.2 or newer.

### Prerequisites

- Debian package manager (Cydia, [Zebra](https://getzbra.com/), [Sileo](https://www.reddit.com/r/jailbreak/comments/fe7t5l/tutorial_the_no_bs_solution_for_sileo_on_unc0ver/), [Installer 5](https://apptapp.me/repo/) or others)

### Installing

0. [**Jailbreak your iDevice**](https://ios.cfw.guide/)
1. Open **Cydia** (or any other debian packages manager)
2. Tap on the **Sources tab**
3. Press **Modify** on the top right
4. Press **Add** 
5. Paste [**Pwnders repo**](https://pwnders.github.io/repo/) and hit **Add source**
6. Wait for sources to refresh
7. Tap on the **Search tab**
8. Search for **"AltStore (ALPHA)"**
9. Hit **Install** on the top right and then **Confirm**

### Signing/Sideloading iPAs

1. Open **AltStore** (located on the homescreen)
2. Tap on the **Settinga tab**
3. Press **Sign in with Apple ID**
4. *Sign in*
5. Tap on the **My Apps tab**
6. Hit the **"+"**
7. Choose the iPA you wish to sign and sideload
8. Profit

### How to check if I did everything correct

1. Open **Settings**
2. Go to **Generals** > **Profiles & Device Management**
3. You should see a certificate containing the iPA prevoiusly signed and sidleoaded

### Join our [**discord server**](https://discord.gg/kzPPbsw) for help!
